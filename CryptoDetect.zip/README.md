# CryptoDetect
Windows program to help identify files encrypted by programs like ransomware

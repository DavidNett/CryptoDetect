﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Crypto File detector  finder")> 
<Assembly: AssemblyDescription("To help find Cryptolocked encrypted files, using multiple methods, and filters, including file signatures for common extentions,  and  expandable for enhancing the application    - DMN - Free to distribute for as long as it is for free")> 
<Assembly: AssemblyCompany("University of Texas Health")> 
<Assembly: AssemblyProduct("Cryptolock finder")> 
<Assembly: AssemblyCopyright("Copyright © UTHealth 2016")> 
<Assembly: AssemblyTrademark("Nett")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("002eed1a-7e5a-404d-9e13-f986e60d0418")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.5")> 
<Assembly: AssemblyFileVersion("1.0.0.5")> 
